package in.navjeevan.app.admin.backend.repository;

public interface NavjeewanAdminUserRepository {

}
