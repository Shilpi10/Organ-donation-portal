package in.navjeevan.app.admin.backend.entity;

public class NavjeewanAdminUser {

}
