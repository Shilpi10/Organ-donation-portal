package in.navjeevan.app.admin.backend.service;

public interface NavjeewanAdminUserService {

}
