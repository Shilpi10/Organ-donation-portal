package in.navjeevan.app.donor.backend.repository;

public interface NavjeewanDonorRepository {

}
