package in.navjeevan.app.donor.backend.service;

public interface NavjeewanDonorService {

}
