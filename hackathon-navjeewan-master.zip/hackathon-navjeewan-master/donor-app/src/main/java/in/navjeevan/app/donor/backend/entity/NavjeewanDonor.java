package in.navjeevan.app.donor.backend.entity;

public class NavjeewanDonor {

}
